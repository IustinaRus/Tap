﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tema2Console.Models;
using Tema2Console.Orders;

namespace Tema2Console.OrderCreator
{
    public interface IOrderCreator
    {
        OOrder Create(Order order);
    }
}
