﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tema2Console.Logger;
using Tema2Console.Models;
using Tema2Console.Orders;

namespace Tema2Console.OrderCreator
{
    public class OOrderCreator : IOrderCreator
    {
        public ILogger _logger;

        public OOrderCreator(ILogger logger)
        {
            _logger = logger;
        }

        public OOrder Create(Order order)
        {
            switch (order.Type)
            {
                case OrderType.Breakfast:
                    return new BreakfastOOrder(_logger);
                case OrderType.Room:
                    return new RoomOOrder(_logger);
                case OrderType.Product:
                    return new ProductOOrder(_logger);
                default:
                    return new UndefinedOOrder(_logger);

            }
        }
    }
}
