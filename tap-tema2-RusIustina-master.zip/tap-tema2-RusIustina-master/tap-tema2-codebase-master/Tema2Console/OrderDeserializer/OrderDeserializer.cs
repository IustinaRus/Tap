﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tema2Console.Models;
using Tema2Console.OrderSerializer;

namespace Tema2Console.OrderDeserializer
{
    public class OrderDeserializer : IOrderDeserializer
    {
        public Order GetOrderFromJsonString(string orderJson)
        {
            return JsonConvert.DeserializeObject<Order>(orderJson, new StringEnumConverter());
        }
    }
}
