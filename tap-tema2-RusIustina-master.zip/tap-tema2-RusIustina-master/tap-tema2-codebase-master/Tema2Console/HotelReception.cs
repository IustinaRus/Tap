﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Tema2Console.FileSource;
using Tema2Console.Logger;
using Tema2Console.Models;
using Tema2Console.OrderCreator;
using Tema2Console.OrderSerializer;

namespace Tema2Console
{
    public class HotelReception
    { 
        private ILogger _logger;
        private IFileSource _fileSource;
        private IOrderDeserializer _orderDeserializer;
        private IOrderCreator _orderCreator;

        public HotelReception()
        {
        }

        public HotelReception(ILogger logger, IFileSource fileSource, IOrderDeserializer orderDeserializer, IOrderCreator orderCreator)
        {
            _logger = logger;
            _fileSource = fileSource;
            _orderDeserializer = orderDeserializer;
            _orderCreator = orderCreator;
        }
        public decimal FinalPrice { get; set; }

        public void ProcessOrder()
        {
            _logger.Log("Start processing...");

            _logger.Log("Loading order from file...");

            var dataJson = _fileSource.GetOrderSource();

            _logger.Log("Deserializing Order object from json data...");
            var order = _orderDeserializer.GetOrderFromJsonString(dataJson);

            if (order == null)
            {
                _logger.Log("Order type not parsed successfully.");
                return;
            }

            var oorder = _orderCreator.Create(order);
            FinalPrice = oorder.ProcOrd(order);

            _logger.Log("Rating completed.");
        }
    }
}
