﻿namespace Tema2Console.Models
{
    public class Order
    {
        public OrderType Type { get; set; }

        public int Quantity { get; set; }

        public decimal Price { get; set; }

        #region Room
        public string ReservationDate { get; set; }
        #endregion

        #region Product
        public string Name { get; set; }
        #endregion

        #region Breakfast
        public string ServingDate { get; set; }
        #endregion
    }
}