﻿namespace Tema2Console.Models
{
    public enum OrderType
    {
        Room = 1,
        Product = 3,
        Breakfast = 2,
        Undefined = 4
    }
}
