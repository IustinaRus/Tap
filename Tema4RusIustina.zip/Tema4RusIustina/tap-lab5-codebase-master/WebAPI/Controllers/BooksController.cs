﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;
using DataLayer.Repository;
using DataLayer.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IRepository<Book> _bookRepository;

        public BooksController(IRepository<Book> bookRepository)
        {
            _bookRepository = bookRepository;
        }

        [HttpGet("get")]
        public ActionResult<IEnumerable<BookOutputDTO>> Get()
        {
            var books = _bookRepository.GetAll();
            var booksDTO = books.Select(book => new BookOutputDTO
            {
                BookId = book.BookId,
                Title = book.Title,
                AuthorId = book.AuthorId
            });
            return Ok(booksDTO);
        }

        [HttpPost("add")]
        public IActionResult Add([FromBody] BookInputDTO bookDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var book = new Book
            {
                Title = bookDTO.Title,
                AuthorId = bookDTO.AuthorId
            };

            _bookRepository.Add(book);
            _bookRepository.SaveChanges();

            return Ok("Added successfully.");
        }

        [HttpPut("update/{id}")]
        public IActionResult Update(Guid id, [FromBody] BookInputDTO bookDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var bookToUpdate = _bookRepository.GetById(id);

            if (bookToUpdate == null)
            {
                return NotFound();
            }

            bookToUpdate.Title = bookDTO.Title;
            bookToUpdate.AuthorId = bookDTO.AuthorId;

            _bookRepository.Update(bookToUpdate);
            _bookRepository.SaveChanges();

            return Ok("Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public IActionResult Delete(Guid id)
        {
            var bookToDelete = _bookRepository.GetById(id);

            if (bookToDelete == null)
            {
                return NotFound();
            }

            _bookRepository.Remove(bookToDelete);
            _bookRepository.SaveChanges();

            return Ok("Deleted successfully.");
        }
    }
}
