﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;
using DataLayer.Repository;
using DataLayer.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthorsController : ControllerBase
    {
        private readonly IRepository<Author> _authorRepository;

        public AuthorsController(IRepository<Author> authorRepository)
        {
            _authorRepository = authorRepository;
        }

        [HttpGet("get")]
        public ActionResult<IEnumerable<AuthorOutputDTO>> Get()
        {
            var authors = _authorRepository.GetAll();
            var authorsDTO = authors.Select(author => new AuthorOutputDTO
            {
                AuthorId = author.AuthorId,
                Name = author.Name
            });
            return Ok(authorsDTO);
        }

        [HttpPost("add")]
        public IActionResult Add([FromBody] AuthorInputDTO authorDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var author = new Author(authorDTO.Name);
            _authorRepository.Add(author);
            _authorRepository.SaveChanges();

            return Ok("Added successfully.");
        }

        [HttpPut("update/{id}")]
        public IActionResult Update(Guid id, [FromBody] AuthorInputDTO authorDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var authorToUpdate = _authorRepository.GetById(id);

            if (authorToUpdate == null)
            {
                return NotFound();
            }

            authorToUpdate.Name = authorDTO.Name;

            _authorRepository.Update(authorToUpdate);
            _authorRepository.SaveChanges();

            return Ok("Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public IActionResult Delete(Guid id)
        {
            var authorToDelete = _authorRepository.GetById(id);

            if (authorToDelete == null)
            {
                return NotFound();
            }

            _authorRepository.Remove(authorToDelete);
            _authorRepository.SaveChanges();

            return Ok("Deleted successfully.");
        }
    }
}
