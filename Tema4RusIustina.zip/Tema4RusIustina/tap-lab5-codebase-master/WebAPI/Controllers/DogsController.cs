﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebAPI.Dto;
using DataLayer.Repository;
using DataLayer.Models;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DogsController : ControllerBase
    {
        private readonly IRepository<Dog> _dogRepository;

        public DogsController(IRepository<Dog> dogRepository)
        {
            _dogRepository = dogRepository;
        }

        [HttpGet("get")]
        public ActionResult<IEnumerable<DogOutputDTO>> Get()
        {
            var dogs = _dogRepository.GetAll();
            var dogsDTO = dogs.Select(dog => new DogOutputDTO
            {
                DogId = dog.DogId,
                Name = dog.Name,
                Age = dog.Age
            });
            return Ok(dogsDTO);
        }

        [HttpPost("add")]
        public IActionResult Add([FromBody] DogInputDTO dogDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var dog = new Dog
            {
                Name = dogDTO.Name,
                Age = dogDTO.Age
            };

            _dogRepository.Add(dog);
            _dogRepository.SaveChanges();

            return Ok("Added successfully.");
        }

        [HttpPut("update/{id}")]
        public IActionResult Update(int id, [FromBody] DogInputDTO dogDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var dogToUpdate = _dogRepository.GetById(id);

            if (dogToUpdate == null)
            {
                return NotFound();
            }

            dogToUpdate.Name = dogDTO.Name;
            dogToUpdate.Age = dogDTO.Age;

            _dogRepository.Update(dogToUpdate);
            _dogRepository.SaveChanges();

            return Ok("Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public IActionResult Delete(int id)
        {
            var dogToDelete = _dogRepository.GetById(id);

            if (dogToDelete == null)
            {
                return NotFound();
            }

            _dogRepository.Remove(dogToDelete);
            _dogRepository.SaveChanges();

            return Ok("Deleted successfully.");
        }
    }
}