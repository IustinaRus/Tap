﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataLayer;
using DataLayer.Models;
using WebAPI.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenresController : ControllerBase
    {
        private readonly MyDbContext _context;

        public GenresController(MyDbContext context)
        {
            _context = context;
        }

        [HttpGet("get")]
        public async Task<ActionResult<IEnumerable<GenreOutputDTO>>> Get()
        {
            var genres = await _context.Genres.ToListAsync();
            var genreDTOs = genres.Select(genre => new GenreOutputDTO
            {
                GenreId = genre.GenreId,
                Name = genre.Name
            }).ToList();

            return Ok(genreDTOs);
        }

        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] GenreInputDTO genreDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var genre = new Genre
            {
                Name = genreDTO.Name
            };

            _context.Add(genre);
            await _context.SaveChangesAsync();

            return Ok("Added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] GenreInputDTO genreDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var genreToUpdate = await _context.Genres.FindAsync(id);

            if (genreToUpdate == null)
            {
                return NotFound();
            }

            genreToUpdate.Name = genreDTO.Name;

            await _context.SaveChangesAsync();

            return Ok("Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var genreToDelete = await _context.Genres.FindAsync(id);

            if (genreToDelete == null)
            {
                return NotFound();
            }

            _context.Genres.Remove(genreToDelete);
            await _context.SaveChangesAsync();

            return Ok("Deleted successfully.");
        }
    }
}
