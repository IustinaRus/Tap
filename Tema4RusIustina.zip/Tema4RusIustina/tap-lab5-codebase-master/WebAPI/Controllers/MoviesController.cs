﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataLayer;
using DataLayer.Models;
using WebAPI.Dto;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly MyDbContext _context;

        public MoviesController(MyDbContext context)
        {
            _context = context;
        }

        [HttpGet("get")]
        public async Task<ActionResult<IEnumerable<MovieOutputDTO>>> Get()
        {
            var movies = await _context.Movies.ToListAsync();
            var movieDTOs = movies.Select(movie => new MovieOutputDTO
            {
                MovieId = movie.MovieId,
                Title = movie.Title
            }).ToList();

            return Ok(movieDTOs);
        }

        [HttpPost("add")]
        public async Task<IActionResult> Add([FromBody] MovieInputDTO movieDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var movie = new Movie
            {
                Title = movieDTO.Title
            };

            _context.Add(movie);
            await _context.SaveChangesAsync();

            return Ok("Added successfully.");
        }

        [HttpPut("update/{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] MovieInputDTO movieDTO)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var movieToUpdate = await _context.Movies.FindAsync(id);

            if (movieToUpdate == null)
            {
                return NotFound();
            }

            movieToUpdate.Title = movieDTO.Title;

            await _context.SaveChangesAsync();

            return Ok("Updated successfully.");
        }

        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var movieToDelete = await _context.Movies.FindAsync(id);

            if (movieToDelete == null)
            {
                return NotFound();
            }

            _context.Movies.Remove(movieToDelete);
            await _context.SaveChangesAsync();

            return Ok("Deleted successfully.");
        }
    }
}
