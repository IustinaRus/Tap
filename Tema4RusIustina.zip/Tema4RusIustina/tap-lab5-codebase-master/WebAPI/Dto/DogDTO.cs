﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI.Dto;

    public class DogInputDTO
{
    [Required(ErrorMessage = "Numele câinelui este obligatoriu.")]
    public string Name { get; set; }

    [Required(ErrorMessage = "Vârsta câinelui este obligatorie.")]
    public int Age { get; set; }
}

    public class DogOutputDTO
    {
        public int DogId { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
    }
