﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI.Dto;

public class DogSpeciesInputDTO
{
    public string Name { get; set; }
    public string Description { get; set; }
}

public class DogSpeciesOutputDTO
{
    public int DogSpeciesId { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
}