﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI.Dto;

public class AuthorInputDTO
{
    [Required(ErrorMessage = "Numele autorului este obligatoriu.")]
    public string Name { get; set; }
}

public class AuthorOutputDTO
{
    public int AuthorId { get; set; }
    public string Name { get; set; }
}

