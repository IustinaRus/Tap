﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI.Dto;

public class GenreInputDTO
{
    public string Name { get; set; }
}

public class GenreOutputDTO
{
    public int GenreId { get; set; }
    public string Name { get; set; }
}