﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI.Dto;

public class MovieInputDTO
{
    public string Title { get; set; }
}

public class MovieOutputDTO
{
    public int MovieId { get; set; }
    public string Title { get; set; }
}
