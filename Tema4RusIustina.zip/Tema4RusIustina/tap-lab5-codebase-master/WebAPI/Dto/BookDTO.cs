﻿using System.ComponentModel.DataAnnotations;

namespace WebAPI.Dto
{
    public class BookInputDTO
    {
        [Required(ErrorMessage = "Titlul cărții este obligatoriu.")]
        public string Title { get; set; }

        [Required(ErrorMessage = "Id-ul autorului este obligatoriu.")]
        public int AuthorId { get; set; }
    }

    public class BookOutputDTO
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public int AuthorId { get; set; }
    }
}