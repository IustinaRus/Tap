﻿using DataLayer.Models;
using Microsoft.EntityFrameworkCore;
using System.Reflection.Emit;

namespace DataLayer
{
    // dotnet ef migrations add Initial
    // dotnet ef database update
    public class MyDbContext : DbContext
    {
        private readonly string _windowsConnectionString = @"Server=.\SQLExpress;Database=Lab5Database1;Trusted_Connection=True;TrustServerCertificate=true";
        //private readonly string _windowsConnectionString = @"Server=localhost\SQLEXPRESS;Database=Lab5Database1;Trusted_Connection=True;TrustServerCertificate=True;";

        public DbSet<User> Users { get; set; }
        public DbSet<UserType> UserTypes { get; set; }

        public DbSet<Author> Authors { get; set; }
        public DbSet<Book> Books { get; set; }

        public DbSet<Dog> Dogs { get; set; }
        public DbSet<DogSpecies> DogsSpecies { get; set; }

        public DbSet<Movie> Movies { get; set; }
        public DbSet<Genre> Genres { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_windowsConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<User>()
                .HasOne(f => f.Type)
                .WithMany(c => c.Users)
                .HasForeignKey(f => f.TypeId);

            builder.Entity<Book>()
                .HasOne(b => b.Author) 
                .WithMany(a => a.Books) 
                .HasForeignKey(b => b.AuthorId);

            builder.Entity<Dog>()
                 .HasOne(d => d.Species) 
                 .WithOne(ds => ds.Dog) 
                 .HasForeignKey<DogSpecies>(ds => ds.DogSpeciesId);

            builder.Entity<Movie>()
                .HasMany(m => m.Genres)
                .WithMany(g => g.Movies)
                .UsingEntity(j =>
                {
                    j.ToTable("MoviesGenres"); 
                    j.Property<int>("MovieId"); 
                    j.Property<int>("GenreId"); 
                    j.HasKey("MovieId", "GenreId"); 
                });

            SeedData(builder);
        }

        private void SeedData(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Author>().HasData(
               new Author("Stephen King") { AuthorId = 1 },
               new Author("J.K. Rowling") { AuthorId = 2 }
            );

            modelBuilder.Entity<Book>().HasData(
                new Book { BookId = 1, Title = "Book 1", AuthorId = 1 },
                new Book { BookId = 2, Title = "Book 2", AuthorId = 2 }
            );



            modelBuilder.Entity<DogSpecies>().HasData(
                new DogSpecies { DogSpeciesId = 1, Name = "Labrador Retriever", Description = "Friendly and outgoing" },
                new DogSpecies { DogSpeciesId = 2, Name = "German Shepherd", Description = "Intelligent and courageous" },
                new DogSpecies { DogSpeciesId = 3, Name = "Golden Retriever", Description = "Loyal and loving" }
            );
            modelBuilder.Entity<Dog>().HasData(
                new Dog { DogId = 1, Name = "Max", Description = "Friendly and energetic", Age = 3, Species = new DogSpecies { DogSpeciesId = 1 } },
                new Dog { DogId = 2, Name = "Bella", Description = "Playful and affectionate", Age = 2, Species = new DogSpecies { DogSpeciesId = 2 } },
                new Dog { DogId = 3, Name = "Charlie", Description = "Intelligent and loyal", Age = 4, Species = new DogSpecies { DogSpeciesId = 3 } }
            );



            modelBuilder.Entity<Genre>().HasData(
                new Genre { GenreId = 1, Name = "Action" },
                new Genre { GenreId = 2, Name = "Comedy" },
                new Genre { GenreId = 3, Name = "Drama" }
            );

            modelBuilder.Entity<Movie>().HasData(
               new Movie { MovieId = 1, Title = "The Shawshank Redemption" },
               new Movie { MovieId = 2, Title = "The Godfather" },
               new Movie { MovieId = 3, Title = "The Dark Knight" }
            );

            modelBuilder.Entity<MovieGenre>().HasData(
              new { MovieId = 1, GenreId = 1 },
              new { MovieId = 1, GenreId = 2 },
              new { MovieId = 2, GenreId = 2 },
              new { MovieId = 2, GenreId = 3 }
            );
        }

    }
}
