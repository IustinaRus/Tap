﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class Dog
    {
        public int DogId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public int Age { get; set; }

        public DogSpecies SpeciesId { get; set; }
        public DogSpecies Species { get; set; } // One-to-one relationship
    }
}
