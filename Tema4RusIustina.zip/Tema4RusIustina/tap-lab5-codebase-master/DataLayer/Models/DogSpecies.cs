﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer.Models
{
    public class DogSpecies
    {
        public int DogSpeciesId { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }

        public Dog Dog { get; set; } // One-to-one relationship
    }
}
