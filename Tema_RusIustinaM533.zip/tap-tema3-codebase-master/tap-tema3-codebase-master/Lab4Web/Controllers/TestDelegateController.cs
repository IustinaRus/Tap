﻿using Lab4Web.Services.Delegate;
using Microsoft.AspNetCore.Mvc;
using static Lab4Web.Services.Delegate.DelegateService;

namespace Lab4Web.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestDelegateController : ControllerBase
    {
        private readonly IDelegateService _delegateService;

        public TestDelegateController(IDelegateService delegateService)
        {
            _delegateService = delegateService;
        }
        
        [HttpGet("Jocuri numerice")]   //1. b)
        public string JocuriNum(string JocAles, string valprim)
        {
            var callback0 = _delegateService.AruncZar;
            var callback1 = _delegateService.Ghicestenr;

            var callback = (JocAles == "Aruncare zar") ? callback0 : (JocAles == "Ghiceste numarul" ? callback1 : null);

            return _delegateService.Joc(valprim, callback);
        }

        [HttpGet("Joc de intuitie")]   //1. a), dar cu expresie lambda
        public string JocuriInt(string JocAles, string valprim)
        {
            Func<string, string> callback = valprimString => _delegateService.PHF(valprim);
            
            return callback != null ? _delegateService.Joc(valprim, callback) : "Jocul selectat nu este valid.";
        }


        [HttpGet("Joc combinat")]  //1. c)
        public string Joculet(string JocAles, string valprim)
        {
            DelegateService joc = new DelegateService();
            _JocDelegate[] _jocuri = new _JocDelegate[] { joc.AruncZar, joc.Ghicestenr, joc.AlegeOCarte }; //o lista de delegates

            _JocDelegate chaindelegate = null;
            foreach (var jocDelegate in _jocuri)
            {
                chaindelegate += jocDelegate;   
            }

            if (chaindelegate != null)
            {
                List<string> results = new List<string>();  //fac o lista in care salvez toate rezultatele obtinute pentru fiecare joc in parte
                foreach (var jocDelegate in _jocuri)
                {
                    results.Add(jocDelegate(valprim));  //aici adaug in lista fiecare rezultat al fiecarui joc
                }

                return string.Join(", ", results);  //combina toate rezultatele obtinute intr-un singur string
            }
            else
            {
                return "Nu ati ales niciun joc.";
            }
        }
    }
}
