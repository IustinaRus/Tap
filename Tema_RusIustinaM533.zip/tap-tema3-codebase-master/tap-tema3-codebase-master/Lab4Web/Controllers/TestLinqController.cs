using Lab4Web.Services.Linq;
using Microsoft.AspNetCore.Mvc;

namespace Lab4Web.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestLinqController : ControllerBase
    {
        private readonly ILinqService _linqService;

        public TestLinqController(ILinqService linqService)
        {
            _linqService = linqService;
        }

        [HttpGet("Ratings")]   
        public List<Carte> Rating(int rate)
        {
            return _linqService.Ratings(rate);
        }

        [HttpGet("FantasyBooks")]
        public List<string> GetFantasyBooks()
        {
            return _linqService.FantasyBooks();
        }

        [HttpGet("Nr de pagini")]
        public int PageNumber(int value)
        {
            return _linqService.NrPagini(value);
        }

        [HttpGet("Grupare carti pe genuri")]
        public Dictionary<string, int> Genre()
        {
            return _linqService.NumarCartiPeGenre();
        }

        [HttpGet("Genuri de carte")]
        public List<Produs> CartiCuGenuri()
        {
            return _linqService.CartiCuGenuri();
        }

        [HttpGet("Carti cu nr de pagini cuprins intre 400 si 600")]
        public List<Carte> CartiCuNumarPagini()
        {
            return _linqService.CartiCuNumarPagini();
        }

    }
}
