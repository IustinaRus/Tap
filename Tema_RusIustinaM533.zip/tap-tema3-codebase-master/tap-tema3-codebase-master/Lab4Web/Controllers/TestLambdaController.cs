using Lab4Web.Services.Lambda;
using Microsoft.AspNetCore.Mvc;

namespace Lab4Web.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TestLambdaController : ControllerBase
    {
        private readonly ILambdaService _lambdaService;

        public TestLambdaController(ILambdaService lambdaService)
        {
            _lambdaService = lambdaService;
        }


        [HttpGet("Salutare!")]
        public string Salutare()
        {
            return _lambdaService.Salut();
        }

        [HttpGet("La revedere!")]
        public string LaRevedere(string stare,string name)
        {
            var lambda = (stare == "Am venit") ? _lambdaService.Salut() : (stare=="Am plecat" ? _lambdaService.LaRevedere(name) : null) ;
            return lambda;
        }

        [HttpGet("Puterea unui numar!")]
        public int PutereNr(int putere, int value)
        {
            var result = _lambdaService.PutereNr(putere,value);
            return result;
        }

        [HttpGet("Test")]
        public string Test(string value)
        {
            return _lambdaService.Test(value);
        }

        [HttpGet("Calcule Matematice")]
        public double Calcule(double value = 15)
        {
            return _lambdaService.Calcule(value);
        }

        [HttpGet("Palindrom")]
        public string Palindrom(int value)
        {
            var tupleValue = _lambdaService.Palindrom(value);
            return $"{tupleValue.Item1} / {tupleValue.Item2}";
        }

        [HttpGet("Suma primelor n nr naturale")]
        public int Sum(int value)
        {
            var result = _lambdaService.SumAsync(value).Result;
            return result;
        }
    }
}
