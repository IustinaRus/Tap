﻿namespace Lab4Web.Services.Delegate
{
    public delegate string _JocDelegate(string valprim);

    public class DelegateService : IDelegateService
    {
        public string Joc(string value, Func<string, string> callback)
        {
            return callback(value);
        }

        public string AruncZar(string valprim)
        {
            Random random = new Random();
            int rezultatZar = random.Next(1, 7);

            if (valprim == rezultatZar.ToString())
            {
                return "Ai câștigat! Zarul a căzut pe " + rezultatZar.ToString();
            }
            else
            {
                return "Ai pierdut! Zarul a căzut pe " + rezultatZar.ToString();
            }
        }

        public string Ghicestenr(string valprim)
        {
            Random random = new Random();
            int numarCorect = random.Next(0, 21);

            if (valprim == numarCorect.ToString())
            {
                return "Felicitări! Ai ghicit numărul corect: " + numarCorect.ToString();
            }
            else
            {
                return "Numărul introdus nu e corect. Încearcă din nou!";
            }
        }

        public string PHF(string valprim)
        {
            string[] optiuni = { "piatra", "hartie", "foarfeca" };
            Random random = new Random();
            int indexAles = random.Next(0, optiuni.Length);
            string optiuneAleasa = optiuni[indexAles];

            if (valprim == optiuneAleasa)
            {
                return "Egalitate! Calculatorul a ales " + optiuneAleasa;
            }
            else if ((valprim == "piatra" && optiuneAleasa == "foarfeca") ||
                     (valprim == "hartie" && optiuneAleasa == "piatra") ||
                     (valprim == "foarfeca" && optiuneAleasa == "hartie"))
            {
                return "Ai câștigat! Calculatorul a ales " + optiuneAleasa;
            }
            else
            {
                return "Ai pierdut! Calculatorul a ales " + optiuneAleasa;
            }
        }

        public string AlegeOCarte(string valprim)
        {
            Random random = new Random();
            int numarCorect = random.Next(0, 14);
            string[] optiuni = { "inima", "romb", "frunza", "trifoi" };
            int indexAles=random.Next(0, optiuni.Length);
            string optiuneAleasa = optiuni[indexAles];

            if (valprim == numarCorect.ToString())
            {
                return "Felicitări! Ai ghicit cartea corecta: " + numarCorect.ToString()+optiuneAleasa;
            }
            else
            {
                return "Nu ai ghicit cartea. Încearcă din nou!";
            }
        }
    }
}
