﻿namespace Lab4Web.Services.Delegate
{
    public interface IDelegateService
    {
        string Joc(string value, Func<string, string> callback);

        string AruncZar(string valprim);
        string Ghicestenr(string valprim);
        string PHF(string valprim);
        string AlegeOCarte(string valprim);
    }
}
