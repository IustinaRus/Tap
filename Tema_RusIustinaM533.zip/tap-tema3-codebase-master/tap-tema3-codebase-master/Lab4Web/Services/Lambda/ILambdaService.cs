﻿namespace Lab4Web.Services.Lambda
{
    public interface ILambdaService
    {

        string Salut();
        string LaRevedere(string name);
        int PutereNr(int putere, int value);
        string Test(string value);
        double Calcule(double value = 15);
        Tuple<string,int> Palindrom(int value);


        Task<int> SumAsync(int value);
    }
}
