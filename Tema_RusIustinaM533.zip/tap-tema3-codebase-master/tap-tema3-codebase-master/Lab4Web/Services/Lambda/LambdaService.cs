﻿namespace Lab4Web.Services.Lambda
{
    public class LambdaService : ILambdaService
    {
        public string Salut()  //fara parametri
        {
            var lambdaExp = () => "Salutare!";
            return lambdaExp();
        }

        public string LaRevedere(string name)  //un parametru
        {
            var lambdaExp = (string nume) => "La revedere, "+nume;
            return lambdaExp(name);
        }

        public int PutereNr(int putere, int value)  //doi parametri
        {
            int p = 1;
            for (int i = 0; i < putere; i++)
            {
                p *= value;
            }
            var lambdaExp = (int num) => p;
            return lambdaExp(value);
        }

        public string Test(string value)  //parametri neutilizati in expresie
        {
            var lambdaExp = (string word) => "Acesta este doar un test!";
            return lambdaExp(value);
        }

        public double Calcule(double value = 15)  //parametri cu valori default scrise 
        {                                         //sub forma de statement block

            var lambdaExp = (double number) =>
            {
                double result = number + number;
                result += number / 2;
                result += number % 10;
                return result;    
            };
            return lambdaExp(value);
            
        }

        public Tuple<string, int> Palindrom(int value)  //tuple ca parametru 
        {
            var lambdaExp = (int num) =>
            {
                bool palindrom = true;
                int nr = num;
                int inversul = 0;
                while (num != 0)
                {
                    inversul = inversul * 10 + num % 10;
                    num = num / 10;
                }
                if (nr != inversul)
                {
                    palindrom = false;
                }
                if (palindrom == true)
                {
                    return Tuple.Create("Numarul dat este palindrom", nr);
                }
                else return Tuple.Create("Numarul dat nu este palindrom", nr);
            };
            return lambdaExp(value);
        }

        public async Task<int> SumAsync(int value)  //expresie Lambda in context asyn
        {
            var lambaExp = async (int num) =>
            { 
                int sum = 0;
                for(int i = 1; i <= num; i++)
                {
                    await Task.Delay(1000);
                    sum += i;
                }
                return sum;
            };

            return await lambaExp(value);
        }


    }
}
