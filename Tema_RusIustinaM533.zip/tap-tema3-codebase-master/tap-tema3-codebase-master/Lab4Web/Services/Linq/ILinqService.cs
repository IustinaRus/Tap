﻿namespace Lab4Web.Services.Linq
{
    public interface ILinqService
    {
        List<Carte> Ratings(int value);
        List<string> FantasyBooks();
        int NrPagini(int value);


        List<Carte> CartiCuNumarPagini();
        Dictionary<string, int> NumarCartiPeGenre();
        List<Produs> CartiCuGenuri();
    }
}
