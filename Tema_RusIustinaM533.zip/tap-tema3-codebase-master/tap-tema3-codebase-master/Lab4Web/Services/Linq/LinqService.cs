﻿namespace Lab4Web.Services.Linq
{
 
    public class LinqService : ILinqService
    {
        private readonly ListaCarti listacarti;

        public LinqService(ListaCarti listaCarti)
        {
            listacarti = listaCarti;
        }

        public List<Carte> Ratings(int value)  //returnarea unei liste de ob fol o clauza where
        {                                        //expresii de interogare

            var query = from carte in listacarti.carti
                        where carte.Rate >= value
                        select carte;

            return query.ToList();
        }

        public List<string> FantasyBooks()  //returnarea unei liste de stringuri cu val unei prop
        {                                      //cu interogari bazate pe metode
            var query = listacarti.carti.Where(carte => carte.Genre == "Fantasy")
                        .Select(carte => carte.Name)
                        .ToList();

            return query;
        }

        public int NrPagini(int value)
        {
            return listacarti.carti.Count(carte => carte.PageNumber >= value);
        }


        public List<Carte> CartiCuNumarPagini()
        {
            var query = listacarti.carti
                                .Where(carte => carte.PageNumber >= 400 && carte.PageNumber <= 600)
                                .ToList();

            return query;
        }
        public Dictionary<string, int> NumarCartiPeGenre()
        {
            var query = from carte in listacarti.carti
                        group carte by carte.Genre into grup
                        select new { Genre = grup.Key, NumarCarti = grup.Count() };

            return query.ToDictionary(x => x.Genre, x => x.NumarCarti);
        }

        public List<Produs> CartiCuGenuri()
        {
            var genuri = new List<string> { "Fantasy", "Horror", "Romance", "Comedy", "Mistery" };

            var query = from carte in listacarti.carti
                        join gen in genuri on carte.Genre equals gen
                        select new Produs { Titlu = carte.Name, Gen = carte.Genre };

            return query.ToList();
        }
    }

    public class Produs
    {
        public string Titlu { get; set; }
        public string Gen { get; set; }
    }

}
