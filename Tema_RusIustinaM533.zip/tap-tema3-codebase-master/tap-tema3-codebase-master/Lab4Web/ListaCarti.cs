﻿namespace Lab4Web
{
    public class ListaCarti
    {
        public List<Carte> carti = new List<Carte>()
        {
            new Carte("Harry Potter", "J.K. Rowling", 500, 5, "Fantasy", "Arthur"),
            new Carte("Carrie", "Stephen King", 300, 5, "Horror", "Idk"),
            new Carte("Game of Thrones", "Martin G.", 600, 3, "Fantasy", "Ceva"),
            new Carte("Me before you", "Jojo Moyes", 400, 5, "Romance", "Litera"),
            new Carte("Crimele de la internat", "Lucinda Riley", 500, 4, "Mystery", "Litera"),
            new Carte("Five feet apart", "I dont know", 400, 5, "Romance", "Litera"),
            new Carte("Miss Peregrine", "Someone", 500, 5, "Fantasy", "Young Art"),
            new Carte("Iubeste-ti viata", "Sophie Kinsella", 400, 4, "Comedy", "Polirom"),
            new Carte("Bookshop on Sena", "Nina George", 400, 5, "Romance", "Litera"),
            new Carte("Origini", "Dan Brown", 600, 2, "Mistery", "Idk"),
        };
    }
}
