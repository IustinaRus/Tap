﻿namespace Lab4Web
{
    public class Carte
    {

        public Carte(string name, string author, int pagenr, int rate, string genre, string publisher) {
            Name = name;
            Author = author;
            PageNumber = pagenr;
            Rate = rate;
            Genre = genre;
            Publisher = publisher;
        }

        public string Name { get; set; }
        public string Author { get; set; }
        public int PageNumber { get; set; }
        public int Rate {  get; set; }
        public string Genre {  get; set; }
        public string Publisher {  get; set; }

    }
}
